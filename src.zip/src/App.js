import React, { useState } from 'react';
import './App.css';
import Main from './components/Main';
import Login from './components/Login'; // Import the Login component

function App() {
  const [loggedIn, setLoggedIn] = useState(false); // State to track login status

  const handleLogin = (credentials) => {
    // Here, you can add your authentication logic
    // For demonstration purposes, let's assume login is successful if username and password are not empty
    if (credentials.username.trim() !== '' && credentials.password.trim() !== '') {
      setLoggedIn(true); // Update login status
    } else {
      alert('Invalid username or password');
    }
  };

  return (
    <div className="App">
      {/* Conditional rendering based on login status */}
      {loggedIn ? (
        <Main />
      ) : (
        <Login onLogin={handleLogin} />
      )}
    </div>
  );
}

export default App;
